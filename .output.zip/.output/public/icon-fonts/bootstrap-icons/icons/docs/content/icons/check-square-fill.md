---
title: Check square fill
categories:
  - Alerts, warnings, and signs
tags:
  - checkmark
  - confirm
  - done
---
